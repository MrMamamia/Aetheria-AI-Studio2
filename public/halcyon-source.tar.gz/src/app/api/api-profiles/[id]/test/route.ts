import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { testConnection } from '@/lib/ai-runtime'
import type { ProviderType } from '@/lib/types'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    const profile = await db.apiProfile.findUnique({ where: { id } })
    if (!profile) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    const body = await req.json().catch(() => ({}))
    const provider = (body.provider || profile.provider || 'zai') as ProviderType
    const baseUrl = body.baseUrl !== undefined ? body.baseUrl : profile.baseUrl ?? undefined
    const model = body.model !== undefined ? body.model : profile.modelName ?? undefined
    // If the request didn't include an apiKey, fall back to the stored one.
    const apiKey =
      body.apiKey && String(body.apiKey).trim().length > 0
        ? String(body.apiKey)
        : profile.apiKey ?? undefined

    const result = await testConnection({
      provider,
      baseUrl,
      apiKey,
      model,
    })

    await db.apiProfile.update({
      where: { id },
      data: {
        lastTestedAt: new Date(),
        lastTestOk: result.ok,
      },
    })

    return NextResponse.json(result)
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    )
  }
}
